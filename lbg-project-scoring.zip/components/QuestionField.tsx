import React from 'react';
import { Question, Option } from '../types';

interface QuestionFieldProps {
  question: Question;
  value: string | number;
  onChange: (val: string | number) => void;
}

const QuestionField: React.FC<QuestionFieldProps> = ({ question, value, onChange }) => {
  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start mb-4">
        <span className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-blue-100 text-blue-600 font-bold rounded-full mr-3 text-sm">
          {question.id}
        </span>
        <div>
          <label className="block text-gray-800 font-medium text-lg">
            {question.text}
          </label>
          {question.subText && (
            <p className="text-gray-500 text-sm mt-1">{question.subText}</p>
          )}
        </div>
      </div>

      <div className="pl-11">
        {question.type === 'radio' && question.options && (
          <div className="space-y-3">
            {question.options.map((opt: Option) => (
              <label 
                key={opt.value} 
                className={`flex items-center p-3 rounded-md border cursor-pointer transition-colors ${
                  value === opt.value 
                    ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' 
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <input
                  type="radio"
                  name={`question-${question.id}`}
                  value={opt.value}
                  checked={value === opt.value}
                  onChange={() => onChange(opt.value)}
                  className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                />
                <span className="ml-3 text-gray-700">{opt.label}</span>
              </label>
            ))}
          </div>
        )}

        {question.type === 'number' && (
          <div className="relative max-w-xs">
            <input
              type="number"
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              placeholder={question.placeholder}
              className="block w-full pl-3 pr-12 py-3 text-base border-gray-300 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow"
            />
            {question.suffix && (
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">{question.suffix}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuestionField;