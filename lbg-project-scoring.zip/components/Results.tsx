import React, { useState } from 'react';
import { ScoringResult, RiskLevel } from '../types';
import { CheckCircle, AlertTriangle, XCircle, Mail, ArrowRight, RefreshCw, Copy, CodeXml } from 'lucide-react';

interface ResultsProps {
  result: ScoringResult;
  onReset: () => void;
  onEmbed: () => void;
}

const Results: React.FC<ResultsProps> = ({ result, onReset, onEmbed }) => {
  const [copied, setCopied] = useState(false);

  const getColorConfig = (level: RiskLevel) => {
    switch (level) {
      case RiskLevel.GO:
        return {
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
          text: 'text-emerald-800',
          icon: <CheckCircle className="w-16 h-16 text-emerald-500 mb-4" />,
          title: 'GO - Dự án Khả thi',
          badge: 'bg-emerald-500'
        };
      case RiskLevel.CAUTION:
        return {
          bg: 'bg-yellow-50',
          border: 'border-yellow-200',
          text: 'text-yellow-800',
          icon: <AlertTriangle className="w-16 h-16 text-yellow-500 mb-4" />,
          title: 'CAUTION - Cần cân nhắc',
          badge: 'bg-yellow-500'
        };
      case RiskLevel.NO_GO_SOFT:
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          text: 'text-orange-800',
          icon: <XCircle className="w-16 h-16 text-orange-500 mb-4" />,
          title: 'NO-GO (Soft) - Rủi ro',
          badge: 'bg-orange-500'
        };
      case RiskLevel.NO_GO_HARD:
        return {
          bg: 'bg-red-50',
          border: 'border-red-200',
          text: 'text-red-800',
          icon: <XCircle className="w-16 h-16 text-red-600 mb-4" />,
          title: 'NO-GO (Hard) - Rủi ro cao',
          badge: 'bg-red-600'
        };
    }
  };

  const config = getColorConfig(result.level);

  const handleCopyEmail = () => {
    if (result.emailTemplate) {
      const fullText = `Subject: ${result.emailTemplate.subject}\n\n${result.emailTemplate.body}`;
      navigator.clipboard.writeText(fullText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="animate-fade-in-up">
      {/* Score Card */}
      <div className={`rounded-xl border-2 ${config.border} ${config.bg} p-8 text-center shadow-lg relative overflow-hidden`}>
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 rounded-full bg-white opacity-20"></div>
        <div className="relative z-10 flex flex-col items-center">
          {config.icon}
          
          <h2 className={`text-3xl font-bold mb-2 ${config.text}`}>{config.title}</h2>
          
          <div className="flex items-center space-x-4 mt-4 mb-6">
            <div className="flex flex-col items-center p-3 bg-white rounded-lg shadow-sm w-32">
              <span className="text-gray-500 text-xs uppercase tracking-wider font-semibold">Risk Score</span>
              <span className={`text-2xl font-bold ${config.text}`}>{result.score} <span className="text-sm text-gray-400 font-normal">/ {result.maxScore}</span></span>
            </div>
            <div className="flex flex-col items-center p-3 bg-white rounded-lg shadow-sm w-32">
              <span className="text-gray-500 text-xs uppercase tracking-wider font-semibold">Confidence</span>
              <span className="text-2xl font-bold text-gray-800">{result.confidence}</span>
            </div>
          </div>

          <p className="text-lg text-gray-700 max-w-2xl bg-white/60 p-4 rounded-lg backdrop-blur-sm border border-white/50">
            {result.message}
          </p>
        </div>
      </div>

      {/* Action Section */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2 flex items-center">
              <ArrowRight className="w-5 h-5 mr-2 text-blue-600" />
              Hành động đề xuất
            </h3>
            <p className="text-gray-600">{result.action}</p>
          </div>
          
          {result.level === RiskLevel.CAUTION && (
             <a href="#" className="mt-4 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 shadow-sm">
               Đặt lịch hẹn LBG ngay
             </a>
          )}
        </div>

        {/* Conditional Email Template for Soft NO-GO */}
        {result.emailTemplate && (
          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
             <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <Mail className="w-5 h-5 mr-2 text-gray-500" />
                  Mẫu Email Phản hồi
                </h3>
                <button 
                  onClick={handleCopyEmail}
                  className="text-xs flex items-center text-blue-600 hover:text-blue-800 font-medium"
                >
                  <Copy className="w-3 h-3 mr-1" />
                  {copied ? "Đã sao chép!" : "Sao chép"}
                </button>
             </div>
             <div className="bg-gray-50 p-3 rounded-md border border-gray-200 text-sm text-gray-700 font-mono whitespace-pre-wrap h-40 overflow-y-auto">
               {result.emailTemplate.body}
             </div>
          </div>
        )}

        {/* Generic Contact for others */}
        {!result.emailTemplate && result.level !== RiskLevel.CAUTION && (
           <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 flex items-center justify-center">
             <div className="text-center">
               <p className="text-gray-500 mb-2">Cần hỗ trợ thêm?</p>
               <a href="mailto:contact@lbg.vn" className="text-blue-600 font-semibold hover:underline">Liên hệ Team LBG</a>
             </div>
           </div>
        )}
      </div>

      <div className="mt-10 flex flex-col items-center space-y-4">
        <button
          onClick={onReset}
          className="inline-flex items-center px-6 py-3 border border-gray-300 shadow-sm text-base font-medium rounded-full text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
        >
          <RefreshCw className="w-5 h-5 mr-2" />
          Đánh giá dự án khác
        </button>

        <button 
          onClick={onEmbed}
          className="inline-flex items-center text-sm text-gray-500 hover:text-blue-600"
        >
          <CodeXml className="w-4 h-4 mr-1" />
          Nhúng / Chia sẻ công cụ này
        </button>
      </div>
    </div>
  );
};

export default Results;