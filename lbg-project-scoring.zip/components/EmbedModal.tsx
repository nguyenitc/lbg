import React, { useState, useEffect } from 'react';
import { X, Copy, Check, CodeXml, Globe } from 'lucide-react';

interface EmbedModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const EmbedModal: React.FC<EmbedModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [embedUrl, setEmbedUrl] = useState('');
  const [embedCode, setEmbedCode] = useState('');

  // Initialize URL only once when mounted
  useEffect(() => {
    setEmbedUrl(window.location.href);
  }, []);

  // Update code whenever URL changes
  useEffect(() => {
    const code = `<iframe 
  src="${embedUrl}" 
  width="100%" 
  height="800" 
  frameborder="0" 
  style="border:0; width:100%; overflow:hidden; min-height: 600px;" 
  title="LBG Project Scoring"
  id="lbg-scoring-frame"
  loading="lazy"
></iframe>
<script>
  window.addEventListener('message', function(e) {
    var iframe = document.getElementById('lbg-scoring-frame');
    if(e.data && e.data.type === 'lbg-resize' && iframe) {
      iframe.style.height = e.data.height + 'px';
    }
  });
</script>`;
    setEmbedCode(code);
  }, [embedUrl]);

  const handleCopy = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        {/* Background overlay */}
        <div 
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" 
          aria-hidden="true" 
          onClick={onClose}
        ></div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
          <div className="absolute top-0 right-0 pt-4 pr-4">
            <button
              type="button"
              className="bg-white rounded-md text-gray-400 hover:text-gray-500 focus:outline-none"
              onClick={onClose}
            >
              <span className="sr-only">Close</span>
              <X className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          
          <div className="sm:flex sm:items-start">
            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
              <CodeXml className="h-6 w-6 text-blue-600" aria-hidden="true" />
            </div>
            <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
              <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                Nhúng vào WordPress / Website
              </h3>
              
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Địa chỉ trang web (URL) của công cụ:
                </label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Globe className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md py-2 border"
                    placeholder="https://your-app.vercel.app"
                    value={embedUrl}
                    onChange={(e) => setEmbedUrl(e.target.value)}
                  />
                </div>
                <p className="mt-1 text-xs text-red-500">
                  * Nếu nhúng bị trắng trang, hãy đảm bảo URL này là link công khai (đã deploy lên Vercel/Netlify/Hosting) chứ không phải Localhost.
                </p>
              </div>

              <div className="mt-4">
                <p className="text-sm text-gray-500 mb-2">
                  Copy đoạn mã dưới đây và dán vào block <strong>Custom HTML</strong> trong WordPress:
                </p>
                
                <div className="relative">
                  <textarea
                    readOnly
                    className="block w-full border border-gray-300 rounded-md bg-gray-50 p-3 text-xs font-mono text-gray-600 focus:ring-blue-500 focus:border-blue-500 resize-none h-32"
                    value={embedCode}
                  />
                  <button
                    onClick={handleCopy}
                    className="absolute top-2 right-2 inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none"
                  >
                    {copied ? <Check className="h-3 w-3 mr-1" /> : <Copy className="h-3 w-3 mr-1" />}
                    {copied ? 'Đã chép' : 'Copy'}
                  </button>
                </div>

                <div className="mt-4 text-xs text-gray-500 bg-gray-50 p-2 rounded border border-gray-200">
                  <span className="font-bold">Mẹo:</span> Nếu WordPress chặn Iframe, bạn có thể cần cài plugin "iframe" hoặc nhờ IT bỏ chặn header <code>X-Frame-Options</code>.
                </div>
              </div>
            </div>
          </div>
          <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse">
            <button
              type="button"
              className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
              onClick={onClose}
            >
              Đóng
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmbedModal;